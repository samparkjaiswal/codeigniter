<?php

class Crud_Model extends CI_Model
{

    public function savedata($data)
    {
        
        $this->db->insert('teacher',$data);
        return true;
    }

	public function showdata()
	{
	$query = $this->db->select('*')->get('teacher')->result();
		return $query;
	}

	public function deletedata($id)
	{
		$query = $this->db->where('id',$id)->delete('teacher');
		return $query;
	}

	public function editdata($id)
	{
		 $this->db->select('*')->where('id',$id);
		$query= $this->db->get('teacher');

		 return $query->row();
	}

	public function updatedata($id,$data)
	{
		
		$this->db->where('id',$id)->update('teacher',$data);
		return true;

	}


	public function logindata($email,$password)
	{
		$this->db->select('name','email','password');
		
		$query = $this->db->where(['email'=>$email,'password'=>$password])->get('teacher')->row();

		return $query;
	}


	public function checkemailpass($authemail,$opass,$npass)
	{
		
		$this->db->select('email','password');
		$query = $this->db->where(['email'=>$authemail,'password'=>$opass])->get('teacher')->row();
		if($query)
		{
			$this->db->where('email',$authemail)->set('password',$npass)->update('teacher');
			return true;
		}
		else
		{
			echo "old password not match";
		}
		
	 
	}
}

?>
