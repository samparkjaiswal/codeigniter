<!doctype html>
<html lang="en">
  <head>
	<title>Display</title>
	<!-- Required meta tags -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<!-- Bootstrap CSS -->
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

	
	<!-- Optional JavaScript -->
	<!-- jQuery first, then Popper.js, then Bootstrap JS -->
	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
		<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>

</head>
  <body>
	  

  <div class="container">
	<div class="row">
		<div class="col-md-12">




<div class="col-md-6">
		<?php if($this->session->flashdata('update')) { ?>

<div class="alert alert-warning">
<button type="button" class="close" data-dismiss="alert">×</button>
<?php echo $this->session->flashdata('update') ?>
</div>

<?php }	?>


<?php if($this->session->flashdata('failed')) { ?>

<div class="alert alert-danger">
<button type="button" class="close" data-dismiss="alert">×</button>
<?php echo $this->session->flashdata('failed') ?>
</div>

<?php }	?>





<?php if($this->session->flashdata('delete')) { ?>

<div class="alert alert-primary">
<button type="button" class="close" data-dismiss="alert">×</button>
<?php echo $this->session->flashdata('delete') ?>
</div>

<?php }	?>


<?php if($this->session->flashdata('error')) { ?>

<div class="alert alert-danger">
<button type="button" class="close" data-dismiss="alert">×</button>
<?php echo $this->session->flashdata('error') ?>
</div>

<?php }	?>

</div>







<h1>Welcome to Dashboard, 
	
<?php
if($this->session->has_userdata('email'))
// if(isset($_SESSION['email']))
{
	echo $this->session->userdata('name');
}
else
{
	echo "Dear Guest";
}
 ?>

</h1>

			<table class="table table-responsive table-striped">

				
					<thead class="table-dark" style="text-align: center;">
						<tr>
						<th>Id</th>
						<th>Name</th>
						<th>Email</th>
						<th colspan="2">Operation</th>
						</tr>
					</thead>
			
				<tbody style="text-align:center">
<?php
				foreach($data as $row)
				{

					echo "
					<tr>
						<td>$row->id</td>
						<td>$row->name</td>
						<td>$row->email</td>
						<td><a href='deldata?id=".$row->id."'><button class='btn btn-danger'>Delete</button></a></td>
						<td><a href='".base_url('editdata/'.$row->id)."'><button class='btn btn-warning'>Edit</button></a></td>
			
						
					</tr>
					";
				}
?>
		<!-- <td><a href='".base_url('index.php/editdata/'.$row->id)."'>Edit</a></td> //it's use we not remove index.php file(via adding .htaccess file  {study from codeigniter docs and youtube})	 -->
		</tbody>
				

			</table>
			<a href="<?php echo base_url('changepass') ?>" style="color:white;text-decoration:none"><button class="btn btn-primary">Change Password</button></a>

			<h2><button class="btn btn-danger"><a href="<?php echo base_url('signout') ?>" style="color:white;text-decoration:none">Logout</a></button></h2>
		</div>
	</div>
  </div>

  </body>
</html>
