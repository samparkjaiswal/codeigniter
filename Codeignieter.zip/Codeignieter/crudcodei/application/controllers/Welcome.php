<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller 
{
	public function __construct() 
	{
        parent::__construct(); 
     	$this->load->database();
		$this->load->model('Crud_Model');
		$this->load->helper('url');
		$this->load->library('session');
		$this->load->library('form_validation');
    }

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/userguide3/general/urls.html
	 */
	public function index()
	{

		$this->load->view('welcome_message');
	}

	public function registration()
	{
		return $this->load->view('form');
	}

	public function form()
	{
		// echo "hellow"; die;

		if(isset($_POST['btn']))
		{


			$this->form_validation->set_error_delimiters('<div class="error">', '</div>'); //it is use for show error and color them
			// $this->form_validation->set_rules('name', 'Username', 'required|callback_checkName'); //callback function for user define massage
			$this->form_validation->set_rules('name', 'Username', 'required');
			$this->form_validation->set_rules('email', 'Email', 'required|valid_email|is_unique[teacher.email]');
			$this->form_validation->set_rules('password', 'Password', 'required');
			$this->form_validation->set_message('is_unique', 'Email already exist!');  //for give custome msg for rule
		

			if($this->form_validation->run())  //it is imp for write
			{

				
				// echo "hewllo"; die;
				$name = $this->input->post('name');
				$email = $this->input->post('email');
				$password = md5($this->input->post('password'));
        
				$data=$this->Crud_Model->savedata(['name'=>$name,'email'=>$email,'password'=>$password]);


				if($data==true)
				{
					$this->session->set_flashdata('success','user registration successfull.!!');

				

					// echo "Data inserted";
				}
				else{
				
					$this->session->set_flashdata('failed','something went wrong.!!');
					// redirect('register');
				
				}

				redirect('register');
			
			}
			else
			{
				$this->load->view('form');
				
				// echo validation_errors();
			
			}

		}
		// redirect('reg');


		// $this->load->view('form');
	}


	// public function checkName($str)   //user define validation (give msg according u)
	// {
	// 	if($str == 'test')
	// 	{
	// 		$this->form_validation->set_message('checkName', 'The field can not be word "test"');
	// 		return FALSE;
	// 	}
	// 	else 
	// 	{
	// 		return TRUE;
	// 	}
		
	// }
	

	public function display()
	{
		if(!$this->session->has_userdata('email'))
		{
			redirect('logindata');
			
		}

		$data = $this->Crud_Model->showdata();

		$this->load->view('show',compact('data'));
	}


	public function delete_data()
	{
		if(!$this->session->has_userdata('email'))
		{
			redirect('logindata');
		}

		$id = $this->input->get('id');
		
		$data =	$this->Crud_Model->deletedata($id);

		if($data)
		{
			$this->session->set_flashdata('delete','Record deleted successfully.!!');
			// redirect('fetchdata');
		}
		else
		{
			$this->session->set_flashdata('error','something went wrong.!!');
		}

		// $this->load->view('show');
		redirect('fetchdata');
	}

	public function edit_data($id)
	{
		if(!$this->session->has_userdata('email'))
		{
			redirect('logindata');
			
		}

		$data =	$this->Crud_Model->editdata($id);

		return $this->load->view('edit',compact('data'));
	}

	public function update_data($id)
	{
		// if(isset($this->input->post('update')))
		if(!$this->session->has_userdata('email'))
		{
			redirect('logindata');
			
		}

		if(isset($_POST['update']))

		{
			$name = $this->input->post('name');
			$email = $this->input->post('email');


		$data = $this->Crud_Model->updatedata($id, array('name'=>$name,'email'=>$email));

		if($data)
		{
			$this->session->set_flashdata('update','Record updated successfully.!!');
			// redirect('fetchdata');
		}
		else
		{
			$this->session->set_flashdata('failed','something went wrong.!!');
		}

		redirect('fetchdata');
		
		}
		
		
	}




	public function login()
	{


		if($this->session->has_userdata('email'))
		{
			redirect('dashbo');
			
		}
		


		$this->form_validation->set_error_delimiters('<div class="error">', '</div>');
		$this->form_validation->set_rules('email','Email','required');
		$this->form_validation->set_rules('password','Password', 'required');

		if($this->form_validation->run())
		{
			$email = $this->input->post('email');
			$password = md5($this->input->post('password'));

			$data = $this->Crud_Model->logindata($email,$password);


			if($data)
			{
				$loginname = $data->name;  //name store in session

				$sessiondata = array(
					'email' =>$email,
					'name' =>$loginname
				);

				
				$this->session->set_userdata($sessiondata);
				$this->session->set_flashdata('login','Login success!!');
				// return	$this->load->view('dash');
				redirect('dashbo');
			}
			else
			{
				$this->session->set_flashdata('failed','wrong email/password, please check.!!');
				redirect('logindata');
			
			}
		}
		else 
		{
			return	$this->load->view('login');
	
		}

	
		
	}

	public function dashboard()
	{	
		if(!$this->session->has_userdata('email'))
		{
			redirect('logindata');
			
		}
		else 
		{
			redirect('fetchdata');
			// return $this->load->view('dash');
		}
		
		
	}

	public function logout()
	{
		session_destroy();

		redirect('logindata');
	}


	public function changepassword()
	{

		if(!$this->session->has_userdata('email'))
		{
			redirect('logindata');
			
		}


		$this->form_validation->set_error_delimiters('<div class="error">', '</div>');
		$this->form_validation->set_rules('opass','Old Password','required');
		$this->form_validation->set_rules('npass','New Password', 'required');


		if($this->form_validation->run())
		{
			$authemail = $this->session->userdata('email');
		
			$opass = md5($this->input->post('opass'));
			$npass = md5($this->input->post('npass'));

			$data = $this->Crud_Model->checkemailpass($authemail,$opass,$npass);
			

			if($data)
			{
				
				$this->session->set_flashdata('changepass','Password change success!!');
				// return	$this->load->view('dash');
				redirect('dashbo');
			}
			else
			{
				$this->session->set_flashdata('failed','wrong old password, please check.!!');
				redirect('changepass');
			
			}
		}
		else 
		{
			return $this->load->view('changepass');
	
		}

		
		
		
	}




}
