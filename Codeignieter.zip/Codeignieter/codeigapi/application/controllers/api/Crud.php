<?php

require APPPATH . 'libraries/REST_Controller.php';

class Crud extends REST_Controller
{
	public function __construct() {
		parent::__construct();
		
	 }

	 public function form_get()
	 {
		echo "helloo our api working fine";
	 }
		
}
