<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller 
{
	public function __construct() 
	{
        parent::__construct(); 
     	$this->load->database();
		$this->load->model('Crud_Model');
		$this->load->helper('url');
    }

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/userguide3/general/urls.html
	 */
	public function index()
	{

		$this->load->view('welcome_message');
	}

	public function form()
	{
		// echo "hellow"; die;

		if(!empty($this->input->post('btn')))
		{
			// echo "hewllo"; die;
			$name = $this->input->post('name');
			$email = $this->input->post('email');
			$password = $this->input->post('password');
        
			$data=$this->Crud_Model->savedata(['name'=>$name,'email'=>$email,'password'=>$password]);


			if($data==true)
			{
				echo "Data Insert";
			}
			else{
				echo "Insertion Failed";
			}

		}

		$this->load->view('form');
	}


	public function display()
	{
		$data = $this->Crud_Model->showdata();

		
		
		$this->load->view('show',compact('data'));
	}


	public function delete_data()
	{
		$id = $this->input->get('id');
		
		$this->Crud_Model->deletedata($id);

		redirect('fetchdata');
	}

	public function edit_data($id)
	{
		
	$data =	$this->Crud_Model->editdata($id);

		return $this->load->view('edit',compact('data'));
	}

	public function update_data($id)
	{
		if(!empty($this->input->post('update')))

		{
			$name = $this->input->post('name');
			$email = $this->input->post('email');


		$data = $this->Crud_Model->updatedata($id, array('name'=>$name,'email'=>$email));

		if($data)
		{
			redirect('fetchdata');
		}
		else
		{
			echo "failed updation";
		}
		
		}
		
	
		
	}
}
