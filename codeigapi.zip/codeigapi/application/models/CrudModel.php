<?php 

defined('BASEPATH') OR exit('No direct script access allowed');

class CrudModel extends CI_Model 
{
	public function signin($data)
	{
		$this->db->insert('user',$data);
		return true;
	}

	public function getdata()
	{
		$query = $this->db->get('user')->result();

		return $query;
		
	}

	public function delete_data($id)
	{
		$query = $this->db->where('id',$id)->delete('user');
		return $query;
	}

	public function fetchdata($id)
	{
		
		$query = $this->db->select('*')->where('id',$id)->get('user');
	 return	$query->row();
	 
	}


	public function update_data($id,$data)
	{
		// print_r($id,$data);die;

		$query = $this->db->where('id',$id)->update('user',$data);

		// $query = $this->db->where('id',$id)->set($data)->update('user');
		return $query;
	}
	

	
}
