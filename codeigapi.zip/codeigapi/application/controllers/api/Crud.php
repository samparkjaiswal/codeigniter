<?php

defined('BASEPATH') OR exit('No direct script access allowed');

require APPPATH . 'libraries/REST_Controller.php';

class Crud extends REST_Controller
{
	public function __construct() 
	{
		
		parent::__construct();
		$this->load->database();
		$this->load->model('CrudModel');
		
		
	 }

	//  public function form_get()  //for testing purpose only 
	//  {
	// 	echo "helloo our api working fine";
	//  }

	public function sign_in_post()
	{
		$data = array(
			'name' => $this->input->post('name'),
			'email' => $this->input->post('email'),
			'password' => $this->input->post('password')
		);

		


		// $name = $this->input->post('name');
		// $emai = $this->input->post('email');
		// $password = $this->input->post('password');

		$insert = $this->CrudModel->signin($data);

		// return $this->response($insert,200);


		if($insert)
		{
			$this->response([
				'status' => true,
				'message' => "Data Inserted"
			]);
		}
		else 
		{
			$this->response([
				'status' => false,
				'message' => "Data not Inserted"
			]);
		}

		// if($insert)
		// {
		// 	$this->response([
		// 		'status' => true,
		// 		'message' => "Data Inserted"
		// 	], Rest_Controller::HTTP_OK);
		// }
		// else 
		// {
		// 	$this->response([
		// 		'status' => false,
		// 		'message' => "Data not Inserted"
		// 	], Rest_Controller::HTTP_BAD_REQUEST);
		// }
	}

	public function display_get()
	{
		$data = $this->CrudModel->getdata();
		
		return $this->response($data, 200);

	}


	public function deletedata_delete($id)
	{
		$data = $this->CrudModel->delete_data($id);

		if($data)
		{
			$this->response([
				'status' => true,
				'message' => 'Data deleted Success'
			]);
		}
		else{
			$this->response([
				'status' => false,
				'message' => 'Deletion faliled'
			]);
		}
	}

	public function peruserdata_get($id)
	{
		$data = $this->CrudModel->fetchdata($id);

		return $this->response($data,200);
	}

	public function updatedata_post($id)
	{
		
		$data = array(
			'name' => $this->input->post('name'),
			'email' => $this->input->post('email'),
			
		);

		$update = $this->CrudModel->update_data($id,$data);

		// if($update)
		// {
		// 	return $this->response([
		// 			'status' => 'ok',
		// 			'data' => $update,
		// 			'message' => 'Data updated'
		// 			]);
		// }


		
		// // return $this->response($update, 200);

		if($update)
		{
			return $this->response([
			'status' => true,
			'message' => 'Data updated'
			]);

		}
		else 
		{
			return $this->response([
				'status' => false,
				'message' => 'Data not updated'
				]);
	
		}

		

	}


	
		
}
