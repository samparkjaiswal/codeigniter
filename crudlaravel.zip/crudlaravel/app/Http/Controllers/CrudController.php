<?php

namespace App\Http\Controllers;

use App\Models\Crud;
use Illuminate\Http\Request;

class CrudController extends Controller
{
    public function reg()
    {
        return view('form');
    }

    public function insert(Request $request)
    {
        $reg = new Crud;

        $reg->name = $request->name;
        $reg->email = $request->email;
        $reg->password = $request->password;

        $reg->save();

        if($reg)
        {
           // echo "data insert";

         return  redirect(route('formreg'));
        }
        else
        {
            echo "failed";
        }

    }
}
