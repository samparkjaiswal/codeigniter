<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Testseeder;

use Illuminate\Support\Facades\Validator;

class SeederController extends Controller
{
    public function webregister()
    {
        return view('form');
    }

    public function webinsert(Request $request)
    {
        $request->validate([

            "name"=>"required",
            "email"=>"required|email",
            "gender"=>"required",
            "address"=>"required",
            "password"=>"required"


        ]);

        $data = new Testseeder();
        $data->name=$request->name;
        $data->email=$request->email;
        $data->gender=$request->gender;
        $data->address=$request->address;
        $data->password=$request->password;
        
        $save= $data->save();

        if($save)
        {
           echo "Data Inserted";
        
        }
        else
        {
            return redirect()->back();
        }
     
    }


    public function webshow()
    {
        $datas = Testseeder::all();

        // $record = compact('datas');

       
        return view('show')->with('datas', $datas);
    }



    public function webdelete($id)
    {
        $data = Testseeder::where('id',$id);
      
      $del =  $data->delete();

      if($del)
      {
        echo "<script>alert('Record Deleted');window.location.href='/webshow'</script>";
      }
      else
      {
        echo "Data not Deleted";
      }

    }
















    public function apiregister(Request $request)
    {
    
      
        $rules= array(
            "name"=>"required",
            "email"=> "required|email",
            "gender"=>"required",
            "address"=> "required",
            "password"=>"required"
        );

        $validator= Validator::make($request->all(),$rules);

        if($validator->fails())
        {
            return $validator->errors();
        }
        else
        {
            // echo "hello";

             $test= new Testseeder();
            
             $test->name= $request->name;
             $test->email= $request->email;
             $test->gender= $request->gender;
             $test->address = $request->address;
             $test->password = $request->password;

             $data =$test->save();

             if($data)
             {
                echo "Data Inserted";
             }
             else
             {
                echo "Data Not Inserted";
             }

        }
       


    }


    public function apishow()
    {
        $data = Testseeder::all();

        return $data;
    }


    public function apidelete($id)
    {
        $data = Testseeder::where('id',$id);

        $del= $data->delete();

        if($del)
        {
            echo "Record Deleted";
        }
        else
        {
            echo "Record Not Deleted";
        }

        


    }


    

    
}
