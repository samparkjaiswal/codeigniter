<!doctype html>
<html lang="en">
  <head>
    <title>Registration</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  </head>
  <body>

    <div class="container">
        <div class="row">
            <div class="col-md-12">
              <h1 style="text-align:center;color:red;font-weight:bold">Registration Form</h1>
               <form action="{{ route('webreg') }}" method="post">

                @csrf
                <div class="form-group">
                  <label for="">Name</label>
                  <input type="text" name="name" id="" class="form-control" value="{{ old('name') }}" placeholder="" aria-describedby="helpId">
                 <span class="text-danger" >@error('name'){{ $message }} @enderror</span>
                </div>

                <div class="form-group">
                  <label for="">Email</label>
                  <input type="text" name="email" id="" value="{{ old('email') }}" class="form-control" placeholder="" aria-describedby="helpId">
                 <span class="text-danger">@error('email') {{ $message }}
                   
                 @enderror</span>
                </div>

                <div class="form-group">
                  <label for="">Gender</label>
                  <input type="radio" name="gender" value="Male" id=""> Male
                  <input type="radio" name="gender" value="Female" id=""> Female
                 <span class="text-danger">@error('gender') {{ $message }}@enderror</span>
                </div>

                <div class="form-group">
                  <label for="">Password</label>
                  <input type="text" name="password" id="" class="form-control" placeholder="" aria-describedby="helpId">
                 <span class="text-danger">@error('password'){{ $message }}
                   
                 @enderror</span>
                </div>

                <div class="form-group">
                  <label for="">Address</label>
                  <textarea name="address" id="" class="form-control"></textarea>
                 <span class="text-danger">@error('address'){{ $message }}
                   
                 @enderror</span>
                </div>

                <button type="submit" class="btn btn-success">Submit</button>
              </form>
            </div>
        </div>
    </div>
      
   
  </body>
</html>