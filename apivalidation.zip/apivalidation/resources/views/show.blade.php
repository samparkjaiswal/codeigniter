
<!doctype html>
<html lang="en">
  <head>
    <title>Display Data</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  </head>
  <body>
      
  <div class="container">

   <div class="row">

    <div class="col-md-10">
    
        <table class="table table-bordered  table-striped" style="text-align:center">
       
         
          
            <thead class="table-dark">
              <tr>
                <th>Id</th>
                <th>Name</th>
                <th>Email</th>
                <th>Gender</th>
                <th>Address</th>
                <th colspan="2">Operation</th>
              </tr>
            </thead>

            <tbody class="">
              @foreach ($datas as $rec)
                
           <tr>  
            <td>{{ $rec->id }}</td>
            <td>{{ $rec->name }}</td>
            <td>{{ $rec->email }}</td>
            <td>{{ $rec->gender }}</td>
            <td>{{ $rec->address }}</td>
            <td><a href=""><span class="fa fa-edit"></span></a></td>
            <td><a href="{{ route('') }}"><span class="fa fa-trash" style="color:red"></span></a></td>
           
           </tr>
              @endforeach

            </tbody>

          
        </table>
     
    </div>

   </div>

  </div>
  </body>
</html>