<?php

use App\Http\Controllers\SeederController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});


Route::get('/webreg',[SeederController::class,'webregister']);

Route::post('/insert',[SeederController::class,'webinsert'])->name('webreg');

Route::get('/webshow',[SeederController::class, 'webshow']); 


Route::get('/webdelete/{id}',[SeederController::class, 'webdelete'])->name('webdel');

