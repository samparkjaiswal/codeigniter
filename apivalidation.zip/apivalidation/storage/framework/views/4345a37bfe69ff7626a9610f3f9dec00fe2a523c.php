
<!doctype html>
<html lang="en">
  <head>
    <title>Display Data</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  </head>
  <body>
      
  <div class="container">

   <div class="row">

    <div class="col-md-10">
    
        <table class="table table-bordered  table-striped" style="text-align:center">
       
         
          
            <thead class="table-dark">
              <tr>
                <th>Id</th>
                <th>Name</th>
                <th>Email</th>
                <th>Gender</th>
                <th>Address</th>
                <th colspan="2">Operation</th>
              </tr>
            </thead>

            <tbody class="">
              <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
           <tr>  
            <td><?php echo e($rec->id); ?></td>
            <td><?php echo e($rec->name); ?></td>
            <td><?php echo e($rec->email); ?></td>
            <td><?php echo e($rec->gender); ?></td>
            <td><?php echo e($rec->address); ?></td>
            <td><a href=""><span class="fa fa-edit"></span></a></td>
            <td><a href=""><span class="fa fa-trash" style="color:red"></span></a></td>
           
           </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>

          
        </table>
     
    </div>

   </div>

  </div>
  </body>
</html><?php /**PATH /opt/lampp/htdocs/apivalidation/resources/views/show.blade.php ENDPATH**/ ?>