<?php
class Crud_model extends CI_Model
{
    public function savedata($data)
    {
       $query= $this->db->insert('student',$data);
       return $query;
    }
    public function show_table()
    {
        $query=$this->db->get('student')->result_array();
        return $query;
    }
    public function delete_record($id)
    {
        $this->db->where('id',$id);
        $this->db->delete('student');
       //return true;
    }
    
     public function show_data($id)
     {
       
        $this->db->select('*');
        $this->db->where('id',$id);
        $query=$this->db->get('student');
        return $query->row_array();
     } 

     public function update_data($id,$update)
     {
      $this->db->select('*');
      $this->db->where('id',$id);
      $this->db->update('student',$update);
      return true;
     }
     public function account($data)
     {
      $this->db->insert('account',$data);
      return true;
     }
    public function login_data($email,$password)
    {
      $this->db->select('id,name,email');
      //print_r($password);
     $query=$this->db->where(['email'=>$email,'password'=>$password])->get('account')->result();
     //print_r($query);die;
      return $query;
    }
    public function check_email($email)
    {
      //echo"$email";die;
      $this->db->select('*');
      $query=$this->db->where(['email'=>$email])->get('account');
      if($query->num_rows())
      {
         return true;
      }
      else
      {
         return false;
      }
    }
   
    public function forgot($email)
    {
      $this->db->select('*');                                        //check email
      $query = $this->db->where(['email' => $email])->get('account');
      if($query->num_rows())
      {
         return true;
      }
      else{
         return false;
      }
    }

    public function forgot_pass($email ,$up)
    {
      
      $this->db->select('*');
      $this->db->where('email',$email);
      $this->db->update('account',$up);
      return true;
    }

   public function check_email_pass($email,$opass)
   {
     $this->db->select('*');
     $query=$this->db->where(['email'=>$email,'password'=>$opass])->get('account');
     return $query->num_rows();
   }
    public function changepass($email,$change)
    {
     $this->db->where('email',$email);
     $this->db->update('account',$change);
     return true;
    }
   public function savedata2($data)
   {
      $query=$this->db->insert('admin',$data);               //insert data
      return $query;                           
   }

   public function show_table2()
   {                                                                //show data
     $query=$this->db->get('admin')->result_array();
      return $query;
   }

   public function delete_record2($id)
   {
      $this->db->where('id',$id);
      $this->db->delete('admin');
      return true;
   }

   public function show_data2($id)
   {
     $this->db->select('*');
     $this->db->where('id',$id);
     $query=$this->db->get('admin');
     return $query->row_array();
   }
   public function update_data2($id,$data)
   {
      //echo "$id";die;
      $this->db->select('*');
      $this->db->where('id',$id);
      $this->db->update('admin',$data);
      return true;
   }
}
?>
