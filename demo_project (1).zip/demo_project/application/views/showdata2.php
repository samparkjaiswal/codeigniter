
<html>
<head>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<title>Display records</title>
<style>
table, th, td {
  border: 1px solid black;
  border-collapse: collapse;
}
</style>
</head>
<body>
    <center>
<table width="1000" border="0" cellspacing="5" cellpadding="5">
       <tr style="background:#CCC;font-size:18px">
        <td>ID</td>
        <td>NAME</td>
        <td>GENDER</td>
        <td>LANGUAGE</td>
        <td>COUNTRY</td>
        <td>DATE</td>
        <td colspan="2">OPRATION</td>
       </tr>
       <?php
       foreach($data as $row)
       {  
        echo "<tr style='font-size:18px'>
        <td>".$row['id']."</td>
        <td>".$row['name']."</td>
        <td>".$row['gender']."</td>
        <td>".$row['language']."</td>
        <td>".$row['country']."</td>
        <td>".$row['date']."</td>
        <td><a href='delete_data2?id=".$row['id']."'><span class='fa fa-trash' style='color:red;font-size:25px'></span></a></td>
        <td><a href='edite_table2?id=".$row['id']."'><span class='fa fa-edit' style='color:blue;font-size:25px'></span></a></td>
        </tr>";
       }
       ?>
        
    </table>
    <center>
     
 </body>
 </html>