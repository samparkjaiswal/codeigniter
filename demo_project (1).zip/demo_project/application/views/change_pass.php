</html>
<head></head>
<body>
   <center>
    <h2 style="color:red">Change Password</h2>
    <form action="" method="post">
     Email <input type="email" name="email" placeholder="Enter your email" required/><br><br>
     Old Password <input type="password" name="opass" placeholder="Enter your old password" required/><br><br>
     New Password <input type="password" name="npass" placeholder="Enter your new password" required/><br><br>
    <!--Confrim <input type="password" name="cpass" placeholder="Enter your old Password" required/><br><br>-->
     <input type="submit" name="submit" value="changePassword" style="color:green"/>
     <p><a href='login'>Login</a></p>
    </form>
   </center>
<body>
</html>