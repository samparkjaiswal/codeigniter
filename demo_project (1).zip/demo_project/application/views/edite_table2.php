<?php 
 $lang = explode("," , $edite['language']);
?>

<html>
    <head></head>
    <body>
        <center>
            <h2>Form Update</h2>
            <form action="" method="post">
                Name <input type="text" name="name" value="<?php echo $edite['name']?>" placeholder="Enter your name" required/><br><br>
                Gender <input type="radio" name="gender" value="male"
                <?php
                if($edite['gender']=='male')
                {
                    echo "checked";
                }
                ?>
                />male
                       <input type="radio" name="gender" value="female" required
                       <?php
                if($edite['gender']=='female')
                {
                    echo "checked";
                }
                ?>
                />female <br><br>
                Language <input type="checkbox" name="language[]" value="php"
                <?php
                if(in_array("php",$lang))
                {
                    echo "checked";
                }
                ?>
                />php
                        <input type="checkbox" name="language[]" value="java"
                        <?php
                if(in_array("java",$lang))
                {
                    echo "checked";
                }

                ?>
                        />java
                        <input type="checkbox" name="language[]" value="python"
                        <?php

                       
                if(in_array("python",$lang))
                {
                    echo "checked";
                }

                ?>
                        />python<br><br>
                Country 
                <select name="country">
                 <option value="india"
                 
                 <?php
                if($edite['country']=='india')
                {
                    echo "selected";
                }
                ?>
                 
                 >india</option>
                 <option value="nepal"
                 <?php
                if($edite['country']=='nepal')
                {
                    echo "selected";
                }
                ?>
                 >nepal</option>
                 <option value="pakistan"
                 <?php
                if($edite['country']=='pakistan')
                {
                    echo "selected";
                }
                ?>
                 
                 >pakistan</option>
                 <option value="japan"
                 <?php
                if($edite['country']=='japan')
                {
                    echo "selected";
                }
                ?>
                 >japan</option>
                </select><br><br>
                <input type="submit" name="submit" value="update" style="color:green"/>
            </form>
        </center>
    </body>
</html>