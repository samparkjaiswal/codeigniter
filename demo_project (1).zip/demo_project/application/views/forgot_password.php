<html>
    <head></head>
    <body>
        <center>
        <h2 style="color:green"><i>Forgot Password</i></h2>
            <form action=""method="post">
                Email: <input type="email" name="email" placeholder="Enter your name"/><br><br>
                Password: <input type="Password" name="password" placeholder="Enter your password"/><br><br>
                <input type="submit" name="submit" value="forgotpassword" style="color:green"/>
                <p><a href="login">LOGIN</a></p>
                
            </form>
        </center>
    </body>
</html>     