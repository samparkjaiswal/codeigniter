<html>
    <head>    </head>
        <body>
            <center><h2 style="color:green"><i>Create Account</i></h2>
            <form action="" method="post">
                Name <input type="name" name="name" placeholder="Enter your name" requried/><br><br>
                Email <input type="email" name="email" placeholder="Enter your email" requried/><br><br>
                Password <input type="password" name="password" placeholder="enter your password" required/><br><br>
                <input type="submit" name="submit" value="Create account" style="color:green"/>
                <p><a href='login'>Login</a></p>
            </form>
           </center>
</body>
</html> 