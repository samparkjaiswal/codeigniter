
<html>
    <head></head>
    <body>
        <center>    
            <h2 style="color:green"><i>Update Data</i></h2>
            <form action="" method="post">
            Name: <input type="text" name="name" value="<?php echo $edite['name']?>" placeholder="Enter your name" required/><br><br>
            Father Name: <input type="text" name="fname" value="<?= $edite['fname']?>" placeholder="Enter your father name" required/><br><br>
            Mother Name: <input type="text" name="mname" value="<?= $edite['mname']?>" placeholder="Enter your mother name" required/><br><br>
            Email: <input type="email" value="<?= $edite['email']?>" name="email" placeholder="Enter your email" required/><br><br>
            Date Of Birth: <input type="date" value="<?= $edite['dob'] ?>" name="dob" required/><br><br>
            Mobile No: <input type="number" value="<?= $edite['mobile']?>" name="mobile" placeholder="Enter your mobile number" required/><br><br>
            Gender: <input type="radio" <?php if($edite['gender'] == 'male'){ echo "checked"; } ?> name="gender" value="male"/>male
                    <input type="radio" <?php if($edite['gender'] == 'female'){ echo "checked"; } ?> name="gender" value="female"/>female
                    <input type="radio" <?php if($edite['gender'] == 'other'){ echo "checked"; } ?> name="gender" value="other" required/>other <br><br>
            Country: <select name="country">
                     <option <?php if($edite['country'] == 'india'){ echo "selected"; } ?> value="india">india</option>
                     <option  <?php if($edite['country'] == 'nepal'){ echo "selected"; } ?> value="nepal">nepal</option>
                     <option <?php if($edite['country'] == 'shreelanka'){ echo "selected"; } ?> value="shreelanka">shreelanka</option>
                     <option  <?php if($edite['country'] == 'japan'){ echo "selected"; } ?> value="japan">japan</option>
                    </select><br><br>
                   <input type="submit" name="btn" style="color:green" value="update"/>
</form>
        </center>
    </body>
</html>