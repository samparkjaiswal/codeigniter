<html>
    <head></head>
    <body>
        <center>
            <h2 style="color:green"><i>Registration Form</i></h2>
            <form action="" method="post">
            Name: <input type="text" name="name" placeholder="Enter your name" /><br><br>
            Father Name: <input type="text" name="fname" placeholder="Enter your father name" /><br><br>
            Mother Name: <input type="text" name="mname" placeholder="Enter your mother name" /><br><br>
            Email: <input type="email" name="email" placeholder="Enter your email" /><br><br>
            Date Of Birth: <input type="date" name="dob"/><br><br>
            Mobile No: <input type="number" name="mobile" placeholder="Enter your mobile number" /><br><br>
            Gender: <input type="radio" name="gender" value="male"/>male
                    <input type="radio" name="gender" value="female"/>female
                    <input type="radio" name="gender" value="other" />other <br><br>
            <!-- Country: <select name="country">
                     <option value="india">india</option>
                     <option value="nepal">nepal</option>
                     <option value="shreelanka">shreelanka</option>
                     <option value="japan">japan</option>
                    </select><br><br> -->
                   <input type="submit" name="btn" style="color:green" value="submit"/>
</form>
        </center>
    </body>
</html>
