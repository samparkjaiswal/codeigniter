<html>
<head></head>
<body>
<center>
    <h2 style="color:red"><i>Image Upload</i></h2>
    <form action=""  method="post" enctype="multipart/form_data">
    <!--  Nmae: <input type="name" name="name" placeholder="Enter your name" required/><br><br> -->
      File: <input type="file" name="photo" required/><br><br>
      <input type="submit" name="submit" value="submit" style="color:green"/>
    </form>
</center>
</body>
</html>