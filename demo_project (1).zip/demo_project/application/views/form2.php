<html>
    <head></head>
    <body>
        <center>
            <h2>Form Profile</h2>
            <form action="" method="post">
                Name <input type="text" name="name" placeholder="Enter your name" required/><br><br>
                Gender <input type="radio" name="gender" value="male"/>male
                       <input type="radio" name="gender" value="female" required/>female <br><br>
                Lanuage <input type="checkbox" name="language[]" value="php"/>php
                        <input type="checkbox" name="language[]" value="java"/>java
                        <input type="checkbox" name="language[]" value="python"/>python<br><br>
                Country 
                <select name="country">
                 <option value="india">india</option>
                 <option value="nepal">nepal</option>
                 <option value="pakistan">pakistan</option>
                 <option value="japan">japan</option>
                </select><br><br>
                <input type="submit" name="submit" value="submit" style="color:green"/>
            </form>
        </center>
    </body>
</html>