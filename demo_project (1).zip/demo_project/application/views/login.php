<html>
    <head></head>
    <body>
        <center>
        <h2 style="color:green"><i>Login ProFile</i></h2>
            <form action=""method="post">
                Email: <input type="email" name="email" placeholder="Enter your name"/><br><br>
                Password: <input type="Password" name="password" placeholder="Enter your password"/><br><br>
                <input type="submit" name="submit" value="Login" style="color:green"/>
                <p><a href='forgot_password'>Forgot Password</a></p>
                <p><a href="change_pass">Change password</a></p>
            </form>
        </center>
    </body>
</html>     