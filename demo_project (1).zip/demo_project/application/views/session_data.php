<html>
    <head></head>
    <body>
        <center>
            <h2 style="color:green"><i>Account Data</i></h2>
            <?php
            
             echo "<pre>";
            print_r($this->session->userdata('data'));
             echo "<pre>";            
            
            ?>
            <center>
    </body>
</html> 