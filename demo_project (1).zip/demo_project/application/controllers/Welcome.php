<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller
 {

	public function __construct()
	{
	/*call CodeIgniter's default Constructor*/
	parent::__construct();
	
	/*load database libray manually*/
	$this->load->database();
	//$this->library('uploade');
	$this->load->library('upload');
	$this->load->helper('form', 'url');
	  
	$this->load->library('session');
	/*load Model*/
	$this->load->model('Crud_model');
	}

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/userguide3/general/urls.html
	 */
	public function index()
	{
		$this->load->view('welcome_message');
	}
	public function form()
	{
		if(!empty($this->input->post('btn')))   // data insert code
         {
			$name=$this->input->post('name');
			$fname=$this->input->post('fname');
			$mname=$this->input->post('mname');
			$email=$this->input->post('email');
			$dob=$this->input->post('dob');
			$mobile=$this->input->post('mobile');
			$gender=$this->input->post('gender');
			// $country=$this->input->post('country');
			$data=$this->Crud_model->savedata((array('name'=>$name,'fname'=>$fname,'mname'=>$mname,'email'=>$email,'dob'=>$dob,
		    'mobile'=>$mobile,'gender'=>$gender)));
			if($data==true)
			{
				echo "data is insert";
			}
			else
			{
				echo "data is not insert";
			}
		 }
		$this->load->view('form');
	}
	public function showdata()
	{
		$data=$this->Crud_model->show_table();
		$this->load->view('showdata',compact('data'));
	}
	public function file_upload()
	{
     //$this->form_validation->set_rules('name','name','trim|required');
		$this->load->view('file_upload');
	}
	//delete data in the database
	public function delete_data()
	{
		$id=$this->input->get('id');
		$this->Crud_model->delete_record($id);
		// $this->showdata();
		redirect('showdata');

	}
     
	public function edite_table()
	{
	   $id=$this->input->get('id');
	   $data['edite']=$this->Crud_model->show_data($id);
		//$id=$this->uri->segment('3');
		//$data['edite']=$this->Crud_model->edite_data($_REQUEST['id']);
		$this->load->view('edite_table',$data);
		if(!empty($this->input->post('btn')))
		{
			//echo"$id";die;
			//print_r($this->input->post()); die;
			$name=$this->input->post('name');
			$fname=$this->input->post('fname');
			
			$mname=$this->input->post('mname');
			$email=$this->input->post('email');
			$dob=$this->input->post('dob');
			$mobile=$this->input->post('mobile');
			$gender=$this->input->post('gender');
			$country=$this->input->post('country');
			$update=$this->Crud_model->update_data($id ,array('name'=>$name,'fname'=>$fname,'mname'=>$mname,'email'=>$email,'dob'=>$dob,
			'mobile'=>$mobile,'gender'=>$gender,'country'=>$country));
			if($update==true)
			{
				redirect('showdata');
			}
			else
			{
				echo "update data not sucessfully";
			}
		}
	}
      
	/*
	public function create_account()
	{
		if($this->input->post('submit'))
		{
			$name=$this->input->post('name');
			$email=$this->input->post('email');
			$password=md5($this->input->post('password'));
			$data=$this->Crud_model->account(array('name'=>$name,'email'=>$email,'password'=>$password));
			if($data==true)
			{
				echo "data insert into database";
			}
		}
		$this->load->view('create_account');
	}
	*/
	public function login()
	{ 
		if(!empty($this->input->post('submit')))
		{ 
			//print_r($this->input->post()); die;
			$email=$this->input->post('email');
			$password=md5($this->input->post('password'));
			$data=$this->Crud_model->login_data($email,$password);
           //session start
		   //print_r($data);die;
		   $this->session->set_userdata('data', $data);

			if($data==true)
			{
				echo"<p style='color:green'>Login Sucessfully</p>";
			}
			else
			{
				echo"<p style='color:green'>Your email and Password Is Wronge</p>";
			}
		}
		$this->load->view('login');
	}
    public function change_pass()
    {             
		if(!empty($this->input->post()))
		{
			$email=$this->input->post('email');
			$opass=md5($this->input->post('opass'));
			$npass=md5($this->input->post('npass'));
			$data=$this->Crud_model->check_email_pass($email,$opass);
			if($data==true)
			{
				$change=$this->Crud_model->changepass($email,array('password'=>$npass));
				if($change==true)
				{
					echo "password change sucessfully";
				}
				else
				{
					echo "password not change";
				}
			}
			else
			{
				echo "password is not matched";
			}
		}                                                    // change password 
		$this->load->view('change_pass');
    }


	public function create_account()
	{
	
		if($this->input->post('submit'))
		{
			//print_r($this->input->post());die;                           //create account
			$name=$this->input->post('name');
			$email=$this->input->post('email');
			$password=md5($this->input->post('password'));
			$data=$this->Crud_model->check_email($email);
			if($data==true)
			{
			    echo "<h4 style='color:red'>your account is allready create</h4>";
			}
			else
			{
				if($this->input->post('submit'))
				{
					$name=$this->input->post('name');
					$email=$this->input->post('email');
					$password=md5($this->input->post('password'));
					$data=$this->Crud_model->account(array('name'=>$name,'email'=>$email,'password'=>$password));
					if($data==true)
					{
						echo "<h4 style='color:red'>your account create sucessfully</h4>";
					}
					else
					{
						echo "your account not secessfully";
					}
				}  
			}
			
		}
	
	     $this->load->view('create_account');
	}	

	
	public function forgot_password()
	{     
		if($this->input->post('submit'))                     // Forgot Password
		{ 
		$email=$this->input->post('email'); 
		$password=md5($this->input->post('password')); 
		$data=$this->Crud_model->forgot($email);
		if($data==true)
		{

           $up=$this->Crud_model->forgot_pass($email,array('password'=>$password));
		   if($up==true)
		   {
			echo "password forgot sucessfully";
		   }
		   else
		   {
			echo "password is not forgot";
		    }
		}
		else
		{
            echo  "email is not mattched";
		}
		
		}   
		                                      
		$this->load->view('forgot_password');
	}
	

	public function form2()    // insert code
	{
		if($this->input->post('submit'))
		{
			$name=$this->input->post('name');
			$gender=$this->input->post('gender');
			$language=$this->input->post('language');
			$language1=implode(',',$language);
			$country=$this->input->post('country');
			$date=date('y-m-d');
			$data=$this->Crud_model->savedata2((array('name'=>$name,'gender'=>$gender,'language'=>$language1,'country'=>$country,'date'=>$date)));
			if($data==true)
			{
				echo "data insert sucessfully";
			}
			else
			{
				echo "data is not insert";
			}
		}
		$this->load->view('form2');           
	}
	public function showdata2()
	{
	  $data=$this->Crud_model->show_table2();           // show data
      $this->load->view('showdata2',compact('data'));
     
	}
           
	public function delete_data2()  //delete data
	{
    
		$id=$this->input->get('id');
		$this->Crud_model->delete_record2($id);
     	redirect('showdata2');
	}
	public function edite_table2()
	{
		$id=$this->input->get('id');
		//$language=$this->input->
		$data['edite']=$this->Crud_model->show_data2($id);
		$this->load->view('edite_table2',$data);
		
		if($this->input->post('submit'))
	   {
		
		  //print_r($this->input->post());die;
		    $name=$this->input->post('name');
			$gender=$this->input->post('gender');
			$language=$this->input->post('language');
			$language1=implode(',',$language);
			$country=$this->input->post('country');
			$date=date('y-m-d');
			$data=$this->Crud_model->update_data2($id,array('name'=>$name,'gender'=>$gender,'language'=>$language1,'country'=>$country,'date'=>$date));
			if($data==true)
			{
				//echo "data update sucessfully";
				redirect('showdata2');
			}
			else
			{
				echo "data is not update";
			}
		
	    }
	}

	public function session_data()
	{
		$this->load->view('session_data');
	}
	public function logout()  //session destroy
	{
     $this->session->sess_destroy();
	}    
     
	public function upload()
	{
	if($this->input->post('submit')) 
	{
		$image=($_FILES['photo']);
		//print_r($image);die;
		//$path='./uploads/';
		$config['upload_path'] ='./uploads/'; 
		$config['allowed_types'] = '*';
		$config['max_size'] = '*';
		$config['max_width']  = '*';
		$config['max_height']  = '*';
		$config['file_name']=$image['photo'];
		 $this->load->library('upload',$config);
		 $this->upload->initialize($config);
		 
		if(!$this->upload->do_upload('photo'))
		{
		   $error=array('error'=>$this->upload->display_errors());
		   print_r($error);die;
		}
		else
		{
		   $data=array('upload_data'=>$this->upload->data());
		   print_r($data);die;      
      	}
	}
    ////print_r($data);die;
	$this->load->view('upload');
	}
}
