<?php

class Crud_Model extends CI_Model
{

    public function savedata($data)
    {
        
        $this->db->insert('teacher',$data);
        return true;
    }

	public function showdata()
	{
	$query = $this->db->select('*')->get('teacher')->result();
		return $query;
	}

	public function deletedata($id)
	{
		$query = $this->db->where('id',$id)->delete('teacher');
		return $query;
	}

	public function editdata($id)
	{
		 $this->db->select('*')->where('id',$id);
		$query= $this->db->get('teacher');

		 return $query->row();
	}

	public function updatedata($id,$data)
	{
		$this->db->select('*')->where('id',$id);
		$this->db->update('teacher',$data);
		return true;

	}
}

?>
