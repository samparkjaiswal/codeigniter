<!doctype html>
<html lang="en">
  <head>
	<title>Title</title>
	<!-- Required meta tags -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<!-- Bootstrap CSS -->
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  </head>
  <body>
	  

  <div class="container">
	<div class="row">
		<div class="col-md-12">

			<table class="table table-responsive table-striped">

				
					<thead class="table-dark" style="text-align: center;">
						<tr>
						<th>Id</th>
						<th>Name</th>
						<th>Email</th>
						<th colspan="2">Operation</th>
						</tr>
					</thead>
			
				<tbody style="text-align:center">
<?php
				foreach($data as $row)
				{

					echo "
					<tr>
						<td>$row->id</td>
						<td>$row->name</td>
						<td>$row->email</td>
						<td><a href='deldata?id=".$row->id."'>Delete</a></td>
						<td><a href='".base_url('editdata/'.$row->id)."'>Edit</a></td>
			
						
					</tr>
					";
				}
?>
		<!-- <td><a href='".base_url('index.php/editdata/'.$row->id)."'>Edit</a></td> //it's use we not remove index.php file(via adding .htaccess file  {study from codeigniter docs and youtube})	 -->
		</tbody>
				

			</table>
			
		</div>
	</div>
  </div>

  </body>
</html>
